let ( = )   : int -> int -> bool = Stdlib.( = )
let ( <> )  : int -> int -> bool = Stdlib.( <> )
let ( < )   : int -> int -> bool = Stdlib.( < )
let ( > )   : int -> int -> bool = Stdlib.( > )
let ( <= )  : int -> int -> bool = Stdlib.( <= )
let ( >= )  : int -> int -> bool = Stdlib.( >= )

let compare : int -> int -> int  = Stdlib.compare
